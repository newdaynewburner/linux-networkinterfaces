# networkinterfaces
A module for working with network interfaces in Linux
